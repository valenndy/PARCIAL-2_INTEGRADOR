import { create } from './services.js';


// Capturar el formulario de creación de tarea
const createTaskForm = document.getElementById('createTaskForm');

// Escuchar el evento de envío del formulario
createTaskForm.addEventListener('submit', async (event) => {
  event.preventDefault(); // Prevenir el envío del formulario por defecto

  // Obtener los valores del formulario
  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;

  // Crear la tarea utilizando la función "create" del servicio
  try {
    const response = await create({ title, description });
    console.log(response); // Manejar la respuesta según necesidad
  } catch (error) {
    console.error('Error:', error); // Manejar el error según necesidad
  }

  // Limpiar los campos del formulario
  createTaskForm.reset();
});
