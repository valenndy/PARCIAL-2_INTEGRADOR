// services.js

const API_BASE_URL = 'http://localhost:8080/';

export async function getTasks() {
  try {
    const response = await fetch(API_BASE_URL + 'tasks/all');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

export async function create(task) {
  try {
    const response = await fetch(API_BASE_URL + 'tasks/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(task)
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

export async function getTasksByState(stateID) {
  try {
    const response = await fetch(API_BASE_URL + `tasks/state/${stateID}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

export async function changeStateOfTask(taskID, stateID) {
  try {
    const response = await fetch(API_BASE_URL + `tasks/${taskID}/state/${stateID}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

export async function deleteTaskByID(taskID) {
  try {
    const response = await fetch(API_BASE_URL + `tasks/delete/${taskID}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}
