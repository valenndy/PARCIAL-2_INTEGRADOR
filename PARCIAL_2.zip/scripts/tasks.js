import { getTasksByState, changeStateOfTask, deleteTaskByID } from './services.js';

// Capturar los elementos de las listas de tareas
const todoTasksList = document.getElementById('todoTasks');
const doingTasksList = document.getElementById('doingTasks');
const doneTasksList = document.getElementById('doneTasks');

// Función para mostrar las tareas según su estado
async function showTasksByState() {
  try {
    const todoTasks = await getTasksByState(1);
    const doingTasks = await getTasksByState(2);
    const doneTasks = await getTasksByState(3);

    todoTasks.forEach(task => {
      const taskItem = createTaskItem(task);
      todoTasksList.appendChild(taskItem);
    });

    doingTasks.forEach(task => {
      const taskItem = createTaskItem(task);
      doingTasksList.appendChild(taskItem);
    });

    doneTasks.forEach(task => {
      const taskItem = createTaskItem(task);
      doneTasksList.appendChild(taskItem);
    });
  } catch (error) {
    console.error('Error:', error);
  }
}

// Función para crear un elemento de tarea
function createTaskItem(task) {
  const taskItem = document.createElement('li');
  taskItem.textContent = `${task.title}: ${task.description}`;

  const changeStateButton = document.createElement('button');
  changeStateButton.textContent = 'Cambiar Estado';
  changeStateButton.addEventListener('click', () => changeTaskState(task.id));

  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Eliminar';
  deleteButton.addEventListener('click', () => deleteTask(task.id));

  taskItem.appendChild(changeStateButton);
  taskItem.appendChild(deleteButton);

  return taskItem;
}

// Función para cambiar el estado de una tarea
async function changeTaskState(taskID) {
  try {
    // Solicitar al usuario el nuevo estado deseado
    const newState = prompt('Ingrese el nuevo estado de la tarea (1: ToDo, 2: Doing, 3: Done)');
    if (!newState) return;

    await changeStateOfTask(taskID, parseInt(newState));
    location.reload(); // Recargar la página para reflejar los cambios
  } catch (error) {
    console.error('Error:', error);
  }
}

// Función para eliminar una tarea
async function deleteTask(taskID) {
  try {
    const confirmDelete = confirm('¿Está seguro que desea eliminar esta tarea?');
    if (!confirmDelete) return;

    await deleteTaskByID(taskID);
    location.reload(); // Recargar la página para reflejar los cambios
  } catch (error) {
    console.error('Error:', error);
  }
}

// Llamar a la función para mostrar las tareas según su estado
showTasksByState();
